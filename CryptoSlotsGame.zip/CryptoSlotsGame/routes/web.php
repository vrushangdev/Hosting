<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */

//ok so we would need to tidy this up a little bit
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect('/register');
})->name('welcome');
Auth::routes();
Auth::routes(['verify' => true]);
Route::get('plan/{id}', 'TransactionController@palnshow')->name('planshow');
Route::get('/login/admin', 'Auth\LoginController@showAdminLoginForm');

Route::get('/register/admin', 'Auth\RegisterController@showAdminRegisterForm');


Route::post('/login/admin', 'Auth\LoginController@adminLogin');

Route::post('/register/admin', 'Auth\RegisterController@createAdmin');
//Route::post('forgot-password', 'ForgotpasswordController@forgotPassword')->name('forgot-password');
//    Route::get('/forgot/password', 'ForgotpasswordController@index')->name('web.forgotpassword');

Route::group(['middleware' => 'auth:admin'], function () {

    Route::view('/admin', 'admin')->name('admin');

    Route::get('/home', 'HomeController@index')->name('home');

    Route::get('/plancreate', 'PlanController@create')->name('plancreate');
    Route::post('storePlans', 'PlanController@store')->name('storePlans');
    Route::get('viewPlans/{id}', 'PlanController@view')->name('viewPlans');
    Route::get('/plan', 'PlanController@index')->name('plan');
    Route::get('deletePlan/{id}', 'PlanController@destroy')->name('deletePlan');
    Route::get('/editPlan/{id}', 'PlanController@edit')->name('editPlan');
    Route::post('updatePlan/{id}', 'PlanController@update')->name('updatePlan');


    Route::get('/transactioncreate', 'TransactionController@create')->name('transactioncreate');
    Route::post('storeTransactions', 'TransactionController@store')->name('storeTransactions');
    Route::get('/transactions', 'TransactionController@index')->name('transactions');
    Route::get('deleteTransaction/{id}', 'TransactionController@destroy')->name('deleteTransaction');

    Route::get('/betscreate', 'BetController@create')->name('betscreate');
    Route::post('storebets', 'BetController@store')->name('storeBets');
    Route::get('/bets', 'BetController@index')->name('bets');
    Route::get('deleteBet/{id}', 'BetController@destroy')->name('deleteBet');

    //Below is DynamicPlanController to dynamically create plan cards
    Route::get('/dynamicPlan', 'DynamicPlanController@index')->name('dynamicPlan');

    //This Are Dashboard Routes | Need To Split Them Into User & Admin Routes
    Route::group(['middleware' => 'auth'], function () {
        Route::resource('user', 'UserController', ['except' => ['show']]);
        Route::get('/profile', ['as' => 'profile.edit', 'uses' => 'ProfileController@edit']);
        Route::put('profile', ['as' => 'profile.update', 'uses' => 'ProfileController@update']);
        Route::put('profile/password', ['as' => 'profile.password', 'uses' => 'ProfileController@password']);
    });
});

Route::group(['middleware' => 'auth:web'], function () {
    //  Route::get('/home', 'HomeController@index')->name('home');
    //This Are Dashboard Routes | Need To Split Them Into User & Admin Routes
    Route::group(['middleware' => 'auth'], function () {
        Route::post('charge', 'TransactionController@charge')->name('charge');
        Route::get('/profile', ['as' => 'profile.edit', 'uses' => 'ProfileController@edit']);
        Route::put('profile', ['as' => 'profile.update', 'uses' => 'ProfileController@update']);
        Route::put('profile/password', ['as' => 'profile.password', 'uses' => 'ProfileController@password']);
    });
});












// Below is BetController to create read update and delete bets




