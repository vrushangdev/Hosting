<?php

use App\Bet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;

/*
  |--------------------------------------------------------------------------
  | API Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register API routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | is assigned the "api" middleware group. Enjoy building your API!
  |
 */

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
Route::post('coinbasehook', 'API\OrderController@store');
//API User Controllers

Route::group(['namespace' => 'API'], function() {
    Route::post('login', 'UserController@login');
    Route::post('register', 'UserController@register');
    Route::group(['middleware' => 'auth:api'], function() {
        Route::post('details', 'UserController@details');
        Route::get('combinations', 'UserController@generate');
        Route::get('combinationstest', 'UserController@generate1');
        Route::get('combinationsfree', 'UserController@generatefree');
        Route::get('createcombinationdata', 'UserController@createcombination');
        Route::get('bets', 'BetController@getBets');
        Route::post('bets', 'BetController@store');
        Route::post('logout', 'UserController@logout');
    });
});



Route::get('chartData', function() {
    $data = getChartData();

    return $data;
});


