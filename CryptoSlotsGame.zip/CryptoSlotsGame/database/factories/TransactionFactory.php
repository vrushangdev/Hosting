<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Transaction;
use Faker\Generator as Faker;

$factory->define(Transaction::class, function (Faker $faker) {
    return [
        //first lets create remote resources


        'transactionId'=>$faker->userName,
        'chargeId'=>$faker->userName,
        'paymentMethod'=>$faker->userName,
        'user_id'=>function(){
            return factory(\App\User::class)->create()->id;
        },
        'plan_id'=>function(){
            return factory(\App\Plan::class)->create()->id;
        },
        'paymentStatus'=>$faker->name,
    ];
});
