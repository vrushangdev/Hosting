<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Plan;
use Faker\Generator as Faker;

$factory->define(Plan::class, function (Faker $faker) {
    return [
        //
        'planName'=>$faker->userName,
        'planCost'=>$faker->numberBetween(0,1000),
        'planDescription'=> $faker->paragraph,
        'coinBasePlanId'=>$faker->text,
    ];
});
