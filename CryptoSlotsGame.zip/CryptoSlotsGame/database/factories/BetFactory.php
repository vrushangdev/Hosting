<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Bet;
use Faker\Generator as Faker;

$factory->define(Bet::class, function (Faker $faker) {
    return [
        //
        'betAmount'=>$faker->numberBetween(100,10000),
        'betWinAmount'=>$faker->numberBetween(100,10000),
        'betWinStatus'=>$faker->boolean,
        'betSelectedPayLines'=>$faker->text,
        'betTime'=>$faker->time(),
         'user_id'=>function(){
            return factory(\App\User::class)->create()->id;
        },
        'game_id'=>function(){
            return factory(\App\Game::class)->create()->id;
        }

    ];
});
