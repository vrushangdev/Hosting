<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>{{ config('app.name', 'Crypto Slots Game') }}</title>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
        <!-- Icons -->
        <link href="{{ asset('argon') }}/vendor/nucleo/css/nucleo.css" rel="stylesheet">
        <link href="{{ asset('argon') }}/vendor/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
        <!-- Argon CSS -->
        <link type="text/css" href="{{ asset('argon') }}/css/argon.css?v=1.0.0" rel="stylesheet">
    </head>
    {{--    //Header Starts From Here--}}
    <body class="{{ $class ?? '' }}">
        <div class="main-content">
            @include('users.partials.header', [
            'title' => __('Hello') . ' '. $userdata[0]["name"],
            'description' => __('Have Been Winning Recently ? Buy Premium Plans To Increase Your Edge & Take A Fortune Home, Still Confused ? Try Out Some Of These Plans'),
            'class' => 'col-lg-7',
            'id'=>$userdata[0]["id"]
            ])
            <div class="container-fluid mt--7">
                <div class="card">
                    <div class="card-header bg-gradient-yellow">
                        <h2 class="mb-0 text-red  ">Play with real money and convert your luck into fortune !!</h2>
                    </div>
                    <div class="card-body">

                        <div class="row row-example">
                            @foreach($dynamicplans as $plan)
                            <div class="col-md-4">
                                <div class="card">
                                    <!-- Card body -->
                                    <div class="card-body">
                                        <a href="#!">
                                            <img
                                                src="https://previews.123rf.com/images/alhovik/alhovik1802/alhovik180200045/95546187-bitcoin-jackpot-cryptocurrency-symbols-on-slot-machine-gambling-games-casino-banner-with-bright-blue.jpg"
                                                class="rounded-circle img-center img-fluid  shadow shadow-lg--hover spin"
                                                style="width: 140px;">
                                        </a>
                                        <div class="pt-4 text-center">
                                            <h5 class="h3 title">
                                                <span class="d-block mb-1"> <?php echo $plan->planName ?></span>
                                                <hr>
                                                <ul class="list-unstyled  my-4  align-content-center">
                                                    <li>

                                                        <span
                                                            class="list-group-item-warning bg-gradient-indigo px-4 d-block opacity-7 py-2 my-2 rounded text-white"><strong class=""><?php echo $plan->planName ?></strong></span>
                                                    </li>
                                                    <li>


                                                        <span
                                                            class="list-group-item-info bg-gradient-blue opacity-7 px-4 d-block py-2 my-2 rounded text-white"><strong class=""><?php echo $plan->planDescription ?></strong></span>
                                                    </li>


                                                </ul>
                                                <hr>
                                                <div
                                                    class="badge-success badge-pill my-2 mx-4  px-1 py-1 text-white bg-gradient-darker">
                                                    <strong>🎰 <i
                                                            class="fa fa-dollar-sign text-success"></i> <?php echo $plan->planCost ?>
                                                        💵
                                                    </strong></div>
                                            </h5>
                                            <div class="mt-3">
                                                <div>

                                                    <form method="post" action="{{ route('charge') }}" autocomplete="off">
                                                        @csrf
                                                        <div class="pl-lg-4">

                                                            <div class="form-group">
                                                                <input type="hidden" name="coinBasePlanId"
                                                                       id="coinBasePlanId"
                                                                       class="form-control form-control-alternative"
                                                                       placeholder="Coinbase Id" value="{{ $plan->id }}"
                                                                       required>
                                                            </div>

                                                            <div class="text-center">
                                                                <button type="submit"
                                                                        class="btn bg-gradient-orange btn-block mt-4 text-white">
                                                                    💰 Start Winning 🤑
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </form>

                                                </div>
                                            </div>


                                        </div>

                                    </div>

                                </div>
                            </div>
                            @endforeach


                            <!-- Modal -->
                        </div>
                    </div>
                </div>
            </div>
            @include('layouts.footers.auth')
        </div>

     
        <script src="{{ asset('argon') }}/vendor/jquery/dist/jquery.min.js"></script>
        <script src="{{ asset('argon') }}/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

        @stack('js')

        <!-- Argon JS -->
        <script src="{{ asset('argon') }}/js/argon.js?v=1.0.0"></script>
    </body>
</html>
