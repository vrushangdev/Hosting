<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Home - Brand</title>
    <link rel="stylesheet" href="{{ URL::asset('/assets/bootstrap/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ URL::asset('/assets/bootstrap/css/main.css') }}">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic">
    <link rel="stylesheet" href="{{URL::asset('/assets/fonts/font-awesome.min.css')}}">
</head>

<body class="bodybaby">
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark nav-wrapper">
        <div class="container-fluid">
            
                 <img class="image-class navbar-brand mr-3" src="{{
                                    asset('assets/img/logo.png')
                 
                                    }}" alt="this is just a demo image" height="50px">
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                            <span class="navbar-toggler-icon"></span>
                        </button>

            <div class="collapse navbar-collapse ml-auto" id="navbarCollapse">
                        <div class="navbar-nav ml-auto">
                        <a href="#" class="nav-item nav-link active">Home</a>
                        <a href="#" class="nav-item nav-link">Services</a>
                        <a href="#" class="nav-item nav-link">About</a>
                        <a href="#" class="nav-item nav-link">Contact</a>
                    </div>
                   
                </div>

        </div>
    </nav>


    <div class="container-fluid">
                <div class="row" >
                    <div class="col column1">
                        <img class="image" src="{{ asset('assets/img/bitsvg.svg')}}" alt="this is just a demo image">
                                <img class="image" src="{{ asset('assets/img/ethsvg.svg')}}" alt="this is just a demo image">
                                <img class="image" src="{{ asset('assets/img/monsvg.svg')}}" alt="this is just a demo image">
                            
                                <img class="image-inner" src="{{ asset('assets/img/ripplesvg.svg')}}" alt="this is just a demo image">
                                <img class="image-inner" src="{{ asset('assets/img/tronsvg.svg')}}" alt="this is just a demo image">
                    </div>

                    <div class="col column2">
                @isset($url)
                <form method="POST" action='{{ url("login/$url") }}' aria-label="{{ __('Login') }}">
                @else
                <form class="form-wrapper" role="form" method="POST" action="{{ route('login') }}">
                @endisset
                    {{ csrf_field() }}
                      <img class="image-now" src="{{ asset('assets/img/newnow.svg')}}">



                            <div class="form-group{{ $errors->has('email') ? ' has-danger' : '' }} mb-3">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                                    </div>
                                    <input class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" placeholder="{{ __('Email') }}" type="email" name="email" value="{{ old('email') }}" value="admin@argon.com" required autofocus>
                                </div>
                                @if ($errors->has('email'))
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="form-group{{ $errors->has('password') ? ' has-danger' : '' }}">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                    </div>
                                    <input class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" placeholder="{{ __('Password') }}" type="password" value="secret" required>
                                </div>
                                @if ($errors->has('password'))
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <!-- <div class="custom-control custom-control-alternative custom-checkbox">
                                <input class="custom-control-input" name="remember" id="customCheckLogin" type="checkbox" {{ old('remember') ? 'checked' : '' }}>
                                <label class="custom-control-label" for="customCheckLogin">
                                    <span class="text-muted">{{ __('Remember me') }}</span>
                                </label>
                            </div> -->
                           <div class="btn-group">
                                <button type="submit" class="btn btn-primary button-wrapper">Sign In</button>
                            </div>
                            <div class="text-center">
                                <a href="{{
                                    route('register')
                                }}"  style="color: yellow ; cursor: pointer ; text-transform: capitalize;">Don't have an account? Sign Up</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    <script src="{{asset('assets/js/jquery.min.js')}}"></script>
    <script src="{{asset('assets/bootstrap/js/bootstrap.min.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    <script src="{{asset('assets/js/freelancer.js')}}"></script>
</body>

</html>
