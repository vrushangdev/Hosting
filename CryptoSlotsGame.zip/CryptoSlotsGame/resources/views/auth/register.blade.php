<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Home - Brand</title>
    <link rel="stylesheet" href="{{ URL::asset('/assets/bootstrap/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ URL::asset('/assets/bootstrap/css/main.css') }}">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic">
    <link rel="stylesheet" href="{{URL::asset('/assets/fonts/font-awesome.min.css')}}">
</head>

<body class="bodybaby">
    <nav class="navbar navbar-expand-sm bg-warning navbar-dark nav-wrapper">
        <div class="container-fluid main-wrapper">
            <img class="image-class navbar-brand mr-3" src="{{ asset('assets/img/logo.png') }}" alt="this is just a demo image" height='50px'>
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                            <span class="navbar-toggler-icon"></span>
                        </button>
         <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav ml-auto">
                        <a href="#" class="nav-item nav-link active">Home</a>
                        <a href="#" class="nav-item nav-link">Services</a>
                        <a href="#" class="nav-item nav-link">About</a>
                        <a href="#" class="nav-item nav-link">Contact</a>
                    </div>
                    
                </div>
        </div>
    </nav>



    <div class="container-fluid">
        <div class="row">
            <div class="col column1">
                <img class="image" src="{{ asset('assets/img/bitsvg.svg') }}" alt="this is just a demo image">
                <img class="image" src="{{ asset('assets/img/ethsvg.svg') }}" alt="this is just a demo image">
                <img class="image" src="{{ asset('assets/img/monsvg.svg') }}" alt="this is just a demo image">
                            
                <img class="image-inner" src="{{ asset('assets/img/ripplesvg.svg') }}" alt="this is just a demo image">
                <img class="image-inner" src="{{ asset('assets/img/ripplesvg.svg') }}" alt="this is just a demo image">
            </div>


            <div class="col column2">    
                @isset($url)
                    <form method="POST" action='{{ url("register/$url") }}' aria-label="{{ __('Register') }}">
                @else
                    <form class="form-wrapper" role="form" method="POST" action="{{ route('register') }}">
                @endisset
                    @csrf
                    
                    <img class="image-now" src="{{ asset('assets/img/newnow.svg') }}">

                    <div class="form-group">
                        <!-- <input class="border rounded form-control forminput-wrapper" type="text" autofocus="" placeholder="First Name" name="fName"> -->
                        <div class="form-group{{ $errors->has('name') ? ' has-danger' : '' }}">
                                <div class="input-group">
                                    <!-- <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-hat-3"></i></span>
                                    </div> -->
                                    <input  class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" placeholder="{{ __('Name') }}" type="text" name="name" value="{{ old('name') }}" required autofocus>
                                </div>
                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <!-- <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                    </div> -->
                                    <input class="form-control" placeholder="{{ __('User Name') }}" type="text" name="username" required>
                                </div>
                            </div>
                            <div class="form-group{{ $errors->has('email') ? ' has-danger' : '' }}">
                                <div class="input-group">
                                    <!-- <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                                    </div> -->
                                    <input class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" placeholder="{{ __('Email') }}" type="email" name="email" value="{{ old('email') }}" required>
                                </div>
                                @if ($errors->has('email'))
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group{{ $errors->has('password') ? ' has-danger' : '' }}">
                                <div class="input-group">
                                    <!-- <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                    </div> -->
                                    <input class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" placeholder="{{ __('Password') }}" type="password" name="password" required>
                                </div>
                                @if ($errors->has('password'))
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>

                        <!-- <input class="border rounded form-control forminput-wrapper" type="email"  name="email" placeholder="Email" autofocus="" inputmode="email"> -->

                        <div class="form-group">
                                <div class="input-group">
                                    <!-- <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                    </div> -->
                                    <input class="form-control" placeholder="{{ __('Confirm Password') }}" type="password" name="password_confirmation" required>
                                </div>
                            </div>

                         </div>
                            <!-- <div class="text-muted font-italic">
                                <small>{{ __('password strength') }}: <span class="text-success font-weight-700">{{ __('strong') }}strong</span></small>
                            </div>
                            <div class="row my-4">
                                <div class="col-12">
                                    <div class="custom-control custom-control-alternative custom-checkbox">
                                        <input class="custom-control-input" id="customCheckRegister" type="checkbox">
                                        <label class="custom-control-label" for="customCheckRegister">
                                            <span class="text-muted">{{ __('I agree with the') }} <a href="#!">{{ __('Privacy Policy') }}</a></span>
                                        </label>
                                    </div>
                                </div>
                            </div> -->
                            <div class="btn-group">
                                <button type="submit" class="btn btn-primary button-wrapper">Sign Up</button>
                            </div>
                            <div class="text-center">
                                <a href="{{
                                    route('login')
                                }}"  style="color: yellow ; cursor: pointer ; text-transform: capitalize;">Already have an account? Sign In</a>
                            </div>

                        <!-- <div class="form-row">
                            <div class="col offset-2">
                                <button class="btn btn-primary btn-lg border rounded float-left formsubmit1-wrapper" type="submit">Log In</button>
                            </div>
                            <div class="col">
                                 <button class="btn btn-primary btn-lg formsubmit-wrapper" type="submit" >Sign Up</button>
                            </div>
                        </div> -->
                    </div>
                </form>
            </div>
        </div>
        <!-- <div class="text-center copyright py-4 text-center text-white" style="background-image: url(&quot;assets/img/header_bg.png&quot;);background-size: cover;background-repeat: no-repeat;padding-bottom: 0px;width: auto;min-width: auto;">
            <div class="container"><small>Copyright ©&nbsp;CryptoSlots 2019</small></div>
        </div>
 -->    </div>
    <script src="{{asset('assets/js/jquery.min.js')}}"></script>
    <script src="{{asset('assets/bootstrap/js/bootstrap.min.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    <script src="{{asset('assets/js/freelancer.js')}}"></script>
</body>

</html>
