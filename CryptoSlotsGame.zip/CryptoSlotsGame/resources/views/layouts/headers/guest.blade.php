<div class="header bg-gradient-indigo py-7 py-lg-8">
    <div class="container">
        <div class="header-body text-center mb-7">
            <div class="row justify-content-center">
                <div class="col-lg-5 col-md-6">
                </div>
            </div>
        </div>
    </div>

</div>
