<div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-12">
        <div class="copyright text-center text-xl-between text-muted">
            &copy; {{ now()->year }} <a href="http://www.arvaantechnolab.com/" class="font-weight-bold ml-1" target="_blank">Crypto Slots Game</a>
                <a href="http://www.arvaantechnolab.com/" class="nav-link" target="_blank">Made with ♥️ in 🇮🇳</a>
        </div>


    </div>



</div>
