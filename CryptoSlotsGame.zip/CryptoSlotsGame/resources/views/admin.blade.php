@extends('layouts.app')

@section('content')
    @include('layouts.headers.cards')

    <div class="container-fluid mt--7">


        <div class="row">


            <div class="col-xl-8 mb-5 mb-xl-0">
                <div class="card">
            <!-- Card header -->
            <div class="card-header">
              <!-- Surtitle -->
              <h6 class="surtitle">Performance</h6>
              <!-- Title -->
              <h5 class="h3 mb-0">Total orders</h5>
            </div>
            <!-- Card body -->
            <div class="card-body">
              <div class="chart"><div class="chartjs-size-monitor"><div class="chartjs-size-monitor-expand"><div class=""></div></div><div class="chartjs-size-monitor-shrink"><div class=""></div></div></div>
                <!-- Chart wrapper -->
                <canvas id="chart-bars" class="chart-canvas chartjs-render-monitor" width="1004" height="700" style="display: block; height: 350px; width: 502px;"></canvas>
              </div>
            </div>
          </div>
            </div>

<div class="col-xl-4">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Best Selling Plans</h3>
                            </div>
                            <div class="col text-right">
                                <a href="{{route('plan')}}" class="btn btn-sm btn-primary">See all</a>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <!-- Projects table -->
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">Plan Name</th>
                                    <th scope="col">Sales</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                             @foreach(getBestPlans() as $plan)
                                <tr>
                                    <th scope="row">
                                       {{$plan->planName}}
                                    </th>
                                    <td>
                                       {{ $plan->sold }}
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <span class="mr-2">{{ ((getPlansSold($plan->id) / 1+getTransactionTotal()) * 100)}}%</span>
                                            <div>
                                                <div class="progress">
                                                <div class="progress-bar bg-gradient-danger" role="progressbar" aria-valuenow="{{ ((getPlansSold($plan->id)/1+getTransactionTotal()) * 100) }}" aria-valuemin="0" aria-valuemax="100" style="width: {{ ((getPlansSold($plan->id)/1+getTransactionTotal()) * 100) }}%;"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    @endforeach
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-5">




        </div>

        @include('layouts.footers.auth')
    </div>
@endsection

@push('js')
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.extension.js"></script>
    <script charset="utf-8">

	function initChart() {

		// Create chart
        // var ordersChart = ordersChart;

		// Save to jQuery object

             $.ajax({

            url: '/api/chartData',

            type: 'GET',
            success: function (data) {

                if (!data.error) {
                     var chart = $('#chart-bars');
                    console.log(data);
                    debugger;
                    console.log(JSON.parse(data));
                    var ordersChart = new Chart(chart, JSON.parse(data));
                    console.log(ordersChart);

                    // chart.data('chart', ordersChart);


                }


            }
        });
	}
	$(document).ready(
	  initChart()
    )




    </script>
@endpush
