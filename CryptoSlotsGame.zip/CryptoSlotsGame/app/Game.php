<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Bet;
class Game extends Model
{
    //
    //first we will get the bet 
    //use helper function to process bet result
    //update bet accordingly 
    //save updated bet
    public function manager(Bet $Bet)
    {
        # code...
        //Get Game Id 
        $gameId = $Bet->gameId;
        //Get Pay Lines
        $payLines = $Bet->betSelectedPayLines;
        //Get Bet Amount 
        $betAmount = $Bet->betAmount;
        //time to call helper functions 
        
    }
}
