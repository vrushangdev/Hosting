<?php

use App\Bet;
use App\Transaction;
use App\User;
use Illuminate\Support\Facades\Request;

//use App\Http\Helpers\HttpRequest;
function getCardDetails() {


    $data = User::all()->count();

    return $data;
}

function getTransactionTotal() {
    $transactions = Transaction::all()->where('paymentStatus', '=', 'charge:confirmed')->count();
    return $transactions;
}

function getTotalRevenue() {
    $revenue = Transaction::all()->where('paymentStatus', '=', 'charge:confirmed')->sum('amountInUsd');
    return $revenue;
}

function getConversionRate() {
    $paidTransactinos = getTransactionTotal();
    $trans = Transaction::all()->count();
    $conversion = $trans === 0 ? 0 : $paidTransactinos / $trans;
    return round($conversion * 100, 2);
}

function getChartData() {
    $data = Transaction::where('paymentStatus', '=', 'charge:confirmed');
    $currentMonth = Date('m');
//m 1-12
    //-6 8| 2
    //
    $period = 6; //90 for 3 months, 180 for 6 months

    $until = strtotime('now');
    $from = strtotime("-$period days");
    $sales = array();
    $monthList = array();
    for ($i = $period; $i > 0; $i--) {

        $sales[$period - $i] = Transaction::all()->where('paymentStatus', '=', 'charge:confirmed')->count();
        $monthList[$period - $i] = 'a';
    }


    $data = ['type' => 'bar', 'data' => ['labels' => ['Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            'datasets' => [
                ['label' => 'Sales',
                    'data' => $sales]
    ]]];

//   $dataForm =  ["data"=>
//   ["datasets"=>[
//       ["data"=>$monthlyData]]]];

    return json_encode($data);
}

function getBestPlans() {
    $plans = \App\Plan::all();
    return $plans;
}

function getPlansSold($id) {
    $totalPlans = Transaction::all()->where('plan_id', '=', $id)->where('paymentStatus', '=', 'CHARGE:CONFIRMED')->count();
    return $totalPlans;
}

function getOrders() {
    $orders = Transaction::all()->where('paymentStatus', '=', 'charge:confirmed');
    return $orders;
}

function getUserBalance($id = 0) {
//    pre($id);
    if ($id != 0) {
        $userdata = User::where("id", $id)->get()->toArray();
        return $userdata[0]['coin_balance'];
    } else {
        $user = Auth::user();
        return $user->coin_balance;
    }
}

function getMyTransactions() {
    $user = Auth::user();
    $mytrsnsactions = Transaction::all()->where('id', '=', $user->id);
    return $mytrsnsactions;
}

function getMyBets() {
    $user = \Illuminate\Support\Facades\Auth::user();
    $myBets = Bet::all()->where('user_id', '=', $user->id)->take(5);
    return $myBets;
}

function _json($code = 200, $message = "", $data = array()) {
    return response()->json(['status_code' => $code, 'message' => $message, 'data' => $data], $code);
}

function validation_message($message, $keys = array()) {
    return $message->all()[0];
}

function pre($data = array(), $para = 0) {
    echo "<pre>";
    print_r($data);
    if ($para == 0) {
        exit();
    }
    echo "</pre>";
}

function getValues($C, $reels) {
    $valList = [];
    foreach ($reels as $reel) {
        array_push($valList, $C[$reel]);
    }
    return $valList;
}

function getRandomCombinations() {
    $COMBINATIONSold = [
        ['1', '1', '1', '2', '2', '2', '3', '3', '3', '3', '4', '4', '4', '4', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K',
            'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', '1', '0', '1', '0', '1', '0', '1', '0', '1', '0',
            '1', '0', '1', '0', '1', '0', '1', '0', '1', '0', '5', '5', '6', '6', '6', '6', '6'],
        ['1', '1', '2', '2', '2', '3', '3', '3', '4', '4', '4', '4', '4', '4', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'K', 'K', 'K', 'K', 'K', 'K', 'K',
            'K', 'K', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', '1', '0', '1', '0', '1', '0', '1', '0',
            '1', '0', '1', '0', '1', '0', '1', '0', '1', '0', '5', '5', '6', '6', '6'],
        ['1', '2', '2', '2', '2', '3', '3', '3', '3', '3', '3', '4', '4', '4', '4', '4', '4', '4', 'A', 'A', 'A', 'A', 'A', 'A', 'K', 'K', 'K', 'K', 'K',
            'K', 'K', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', '1', '0', '1', '0', '1', '0', '1', '0', '1', '0',
            '1', '0', '1', '0', '1', '0', '5', '5', '5', '6', '6', '6', '6', '6'],
        ['1', '1', '1', '2', '2', '2', '2', '3', '3', '3', '3', '3', '4', '4', '4', '4', '4', '4', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'K', 'K', 'K', 'K',
            'K', 'K', 'K', 'K', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', '1', '0', '1', '0', '1', '0',
            '1', '0', '1', '0', '1', '0', '1', '0', '1', '0', '5', '5', '6', '6', '6'],
        ['1', '1', '1', '2', '2', '2', '3', '3', '3', '3', '4', '4', '4', '4', '4', '4', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'K', 'K', 'K', 'K', 'K',
            'K', 'K', 'K', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', '1', '0', '1', '0', '1', '0', '1', '0', '1', '0',
            '1', '0', '1', '0', '1', '0', '5', '5', '6', '6', '6', '6', '6'],
    ];
    $COMBINATIONS = [
        ['1', '1', '1', '2', '2', '2', '3', '3', '3', '3', '4', '4', '4', '4', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K',
            'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', '10', '10', '10', '10', '10',
            '10', '10', '10', '10', '10', '5', '5', '6', '6', '6', '6', '6'],
        ['1', '1', '2', '2', '2', '3', '3', '3', '4', '4', '4', '4', '4', '4', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'K', 'K', 'K', 'K', 'K', 'K', 'K',
            'K', 'K', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', '10', '10', '10', '10',
            '10', '10', '10', '10', '10', '5', '5', '6', '6', '6'],
        ['1', '2', '2', '2', '2', '3', '3', '3', '3', '3', '3', '4', '4', '4', '4', '4', '4', '4', 'A', 'A', 'A', 'A', 'A', 'A', 'K', 'K', 'K', 'K', 'K',
            'K', 'K', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', '10', '10', '10', '10', '10',
            '10', '10', '10', '5', '5', '5', '6', '6', '6', '6', '6'],
        ['1', '1', '1', '2', '2', '2', '2', '3', '3', '3', '3', '3', '4', '4', '4', '4', '4', '4', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'K', 'K', 'K', 'K',
            'K', 'K', 'K', 'K', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', '10', '10', '10',
            '10', '10', '10', '10', '10', '5', '5', '6', '6', '6'],
        ['1', '1', '1', '2', '2', '2', '3', '3', '3', '3', '4', '4', '4', '4', '4', '4', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'K', 'K', 'K', 'K', 'K',
            'K', 'K', 'K', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', '10', '10', '10', '10', '10',
            '10', '10', '10', '5', '5', '6', '6', '6', '6', '6'],
    ];

    $COMBINATIONS = [
        ['1', '2', '3', '4', 'A', 'K', 'K', 'K', 'K', 'Q', 'Q', 'Q', 'Q', 'J', 'J', '10', '10', '10', '5', '6'],
        ['1', '2', '3', '4', 'A', 'A', 'K', 'K', 'K', 'Q', 'Q', 'Q', 'J', 'J', 'J', '10', '10', '5', '5', '6'],
        ['A', 'A', 'K', 'K', 'K', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', '10', '10', '10', '10', '5', '5', '6', '6'],
        ['1', '2', '3', '4', 'A', 'A', 'K', 'K', 'Q', 'Q', 'J', 'J', '10', '10', '10', '10', '5', '5', '5', '5'],
        ['2', '3', '4', 'A', 'A', 'K', 'K', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', '10', '10', '10', '10', '6', '6'],
    ];
    $count = 0;
    $cnt = 1;
    $currentRandomCombinations = [];
    foreach ($COMBINATIONS as $combination) {
        $randElements = array_rand($combination, 3);
        $currentRandomCombinations['column' . $cnt++] = implode(',', getValues($COMBINATIONS[$count], $randElements));
        $count++;
    }
    return $currentRandomCombinations;
}

//Checkout Function Not Working so we  moved to using charge :)
// function createCheckout($msg)
// {
// ////$name = "vrushang";
// ////$desc = "desc temp";
// ////$cost = "100";
// ////$msg = "{\"name\": \"$name\",\"description\": \"$desc\",\"local_price\": {\"amount\": \"$cost\",\"currency\": \"USD\"},\"pricing_type\": \"fixed_price\",\"requested_info\": [\"email\"]}";
// ////$newMsg="{\"name\": \"The Sovereign Individual\",\"description\": \"Mastering the Transition to the Information Age\",\"local_price\": {\"amount\": \"100.00\",\"currency\": \"USD\"},\"pricing_type\": \"fixed_price\",\"requested_info\": [\"email\"]}";
// //
// //echo $msg;
// //echo $newMsg;
// $curl = curl_init();
// curl_setopt_array($curl, array(
//   CURLOPT_URL => "https://api.commerce.coinbase.com/checkouts",
//   CURLOPT_RETURNTRANSFER => true,
//   CURLOPT_ENCODING => "",
//   CURLOPT_MAXREDIRS => 10,
//   CURLOPT_TIMEOUT => 30,
//   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//   CURLOPT_CUSTOMREQUEST => "POST",
//   CURLOPT_POSTFIELDS => $msg,
//   CURLOPT_SSL_VERIFYPEER=>false,
//   CURLOPT_HTTPHEADER => array(
//     "Accept: */*",
//     "Accept-Encoding: gzip, deflate",
//     "Cache-Control: no-cache",
//     "Connection: keep-alive",
//     "Content-Length: 213",
//     "Content-Type: application/json",
//     "Cookie: __cfduid=d8528b2aa10f0be1e422a78cc905d824c1573040124",
//     "Host: api.commerce.coinbase.com",
//     "Postman-Token: a10a8f85-2465-453d-ada2-c1bcf35546d1,7f0d25f9-2791-4f6d-91d7-9a0085c0b51c",
//     "User-Agent: PostmanRuntime/7.19.0",
//     "X-CC-Api-Key: 3014aec0-f38e-4ad9-9310-32ff50fdaffc",
//     "X-CC-Version: 2018-03-22",
//     "cache-control: no-cache"
//   ),
// ));
// $response = curl_exec($curl);
// $err = curl_error($curl);
// curl_close($curl);
// if ($err) {
//   echo "cURL Error #:" . $err;
// } else {
//   echo $response;
// }
// }
?>
