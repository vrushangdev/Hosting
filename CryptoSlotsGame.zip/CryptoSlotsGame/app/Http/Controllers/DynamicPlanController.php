<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DynamicPlanController extends Controller
{
    public function index(Request $request)

    {

        $dynamicplans = DB::table('plans')->get();

        return view('profile.edit' , ['dynamicplans' => $dynamicplans]);
    }
}
