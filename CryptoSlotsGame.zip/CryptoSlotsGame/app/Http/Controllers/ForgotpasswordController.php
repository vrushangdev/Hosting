<?php

namespace App\Http\Controllers\WEB;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Illuminate\Support\Facades\Password;
use App\Message;
Use Redirect;
use Session;

class ForgotpasswordController extends Controller {

    public function index() {
        return view('forgotpassword');
    }

    public function forgotPassword(Request $request) {
        $validator = Validator::make($request->all(), [
                    'email' => 'required|email'
        ]);
        if ($validator->fails()) {
            $message = validation_message($validator->errors());
            return Redirect::back()->withErrors($message);
        }
         $response = Password::sendResetLink($request->only('email'), function (Message $message) {
                    $message->subject(Config::get('auth.recovery_email_subject'));
                });
        switch ($response) {
            case Password::RESET_LINK_SENT: {
               
                    Session::flash('message','Successfully Send Link ');
                    Session::flash('alert-class', 'alert-success');
                    return redirect("/web/forgot/password");
                    
                }
            case Password::INVALID_USER: {
                    Session::flash('message', 'This Email Is Not Register With Us!');
                    Session::flash('alert-class', 'alert-danger');
                    return redirect("/web/forgot/password");
                }
        }
    }

}
