<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use function Sodium\add;
use DB;

class UserController extends Controller {

    public $successStatus = 200;

    /**
     * login api
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request) {
        $input = $request->all();
//        pre($input);

        $rules = [
            'username' => 'required',
            'password' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {

            $message = validation_message($validator->errors());

            return _json(401, $message);
        }
//        pre($input);;
        if (isset($input['token']) && !empty($input['token'])) {
            if (Auth::attempt(['username' => request('username'), 'password' => request('password'), "remember_token" => $input['token']])) {
                $user = Auth::user();
                $token = $user->createToken('MyApp')->accessToken;
                $user->remember_token = $token;
                $user->isLogin = 1;
                $user->update();
                $user['token'] = $token;
                return _json(200, 'Logged In Successfully', $user);
            } else {
                return _json(401, 'User Already Logged In');
            }
        } else {
            if (Auth::attempt(['username' => $input['username'], 'password' => $input['password']])) {
                $user = Auth::user();
                $token = $user->createToken('MyApp')->accessToken;
                if (empty($user->remember_token)) {
                    $user->remember_token = $token;
                    $user->isLogin = 1;
                    $user->update();
                    $user['token'] = $token;
                    return _json(200, 'Logged In Successfully', $user);
                } else {
                    return _json(401, 'User Already Logged In');
                }
            } else {
                return _json(401, 'UserName And Password Not Match Please Try Again');
            }
        }
        if (Auth::attempt(['username' => $input['username'], 'password' => $input['password']])) {
            $user = Auth::user();
            $token = $user->createToken('MyApp')->accessToken;
            if (isset($input['token']) && !empty($user->remember_token) && $input['token'] != $user->remember_token) {
//            if (isset($request->token) && $user->isLogin == 1 && request('token') != $user->remember_token&&!empty($user->remember_token)) {
                return _json(401, 'User Already Logged In');
            } else {
                $user->remember_token = $token;
                $user->isLogin = 1;
                $user->update();
            }
            $user['token'] = $token;
//            $user['token1'] = $input['token'];
//            if(! $user->isLogin){
//                return _json(401,'User Already Logged In');
//            }else{
//                $user->isLogin = false;
//            }

            return _json(200, 'Logged In Successfully', $user);
        } else {
            return _json(401, 'UserName And Password Not Match Please Try Again');
        }
    }

    /**
     * Register api
     *
     * @return \Illuminate\Http\Response
     */
    public function register(Request $request) {
//        if($request->method=="GET"){
//            return response()->json(['status_code'=>401,'error'=>'get method not allowed']);
//        }
        $validator = Validator::make($request->all(), [
                    'name' => 'required',
                    'email' => 'required|email|unique:users,email',
                    'password' => 'required',
                    'c_password' => 'required|same:password',
                    'username' => 'required|unique:users,username'
        ]);
        if ($validator->fails()) {
            $message = validation_message($validator->errors());
            return _json(401, $message);
        }
        $input = $request->all();
        $input['password'] = bcrypt($input['password']);
        try {
            $user = User::create($input);
            $success['token'] = $user->createToken('MyApp')->accessToken;
            $success['name'] = $user->name;
            $user->remember_token = $success['token'];
            $user->isLogin = 1;
            $user->update();

            return _json(200, 'User Registered Succesfully', $success);
        } catch (Exception $e) {

            return _json(401, $e->getMessage());
        }
    }

    /**
     * details api
     *
     * @return \Illuminate\Http\Response
     */
    public function details() {
        $user = Auth::user();
        $user['coin_purchas_url'] = url("plan/" . $user->id);
        return _json(200, 'User Details', $user);
    }

    public function generate() {
        $reels = [];
        try {
            for ($i = 1; $i < 6; $i++) {
                //To Use Eloquent Query's Rather Then Classic Query's To Make It Faster .
//                $required_view = 'combinations_reel_' . $i;
                $randomCombination = DB::select('SELECT * from combinations WHERE reel_number=' . $i . ' AND used_before="0" ORDER BY RAND() LIMIT 1');
//                pre($randomCombination,0);
                if (count($randomCombination) < 1) {
                    $this->resetDatabase($i);
                }
                $combinationId = $randomCombination[0]->id;
                $indexvalue = "column" . $i;
                $reels[$indexvalue] = str_replace(" ", "", $randomCombination[0]->combination);
//                array_push($reels, array($indexvalue=>$randomCombination[0]->combination));
                DB::update('UPDATE combinations SET used_before="1" WHERE id= ?', [$combinationId]);
            }
            return _json(200, 'combinations', $reels);
//            pre($reels);
        } catch (\Exception $e) {
            $data['exception_generated'] = $e->getMessage();
            $data['info'] = "Database Is Empty , Let Me Do The Reset";
            $data['waiting_time_in_seconds'] = 100;
            return response()->json($data, 200)->header('Content-Type', 'application/json');
        }
    }

    public function createcombination() {
        ini_set('max_execution_time', '0');
        $COMBINATIONS = [
            ['1', '2', '3', '4', 'A', 'K', 'K', 'K', 'K', 'Q', 'Q', 'Q', 'Q', 'J', 'J', '10', '10', '10', '5', '6'],
            ['1', '2', '3', '4', 'A', 'A', 'K', 'K', 'K', 'Q', 'Q', 'Q', 'J', 'J', 'J', '10', '10', '5', '5', '6'],
            ['A', 'A', 'K', 'K', 'K', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', '10', '10', '10', '10', '5', '5', '6', '6'],
            ['1', '2', '3', '4', 'A', 'A', 'K', 'K', 'Q', 'Q', 'J', 'J', '10', '10', '10', '10', '5', '5', '5', '5'],
            ['2', '3', '4', 'A', 'A', 'K', 'K', 'Q', 'Q', 'Q', 'J', 'J', 'J', 'J', '10', '10', '10', '10', '6', '6'],
        ];
        $count = 0;
        $currentRandomCombinations = [];
        for ($i = 0; $i < 1000000; $i++) {
            $cnt = 1;
            foreach ($COMBINATIONS as $combination) {
                $randElements = array_rand($combination, 3);
                $currentRandomCombinations = implode(',', getValues($combination, $randElements));
                $randomCombination = DB::table("comination_free")
                                ->where("reel_number", "=", $cnt)
                                ->where("combinations", "=", $currentRandomCombinations)
                                ->get()->toArray();
                if (count($randomCombination) < 1) {
                    $id = DB::table('comination_free')->insertGetId(
                            ['combinations' => $currentRandomCombinations, 'reel_number' => $cnt, "is_used" => "0"]
                    );
                }
                $cnt++;
            }
        }
        return "dsfdsfsdfdf";
    }

    public function generatefree() {
        $reels = [];
        try {
            for ($i = 1; $i < 6; $i++) {
                //To Use Eloquent Query's Rather Then Classic Query's To Make It Faster .
                $randomCombination = DB::select('SELECT * from comination_free WHERE reel_number=' . $i . ' AND is_used="0" ORDER BY RAND() LIMIT 1');
                if (count($randomCombination) < 1) {
                    $this->resetDatabasefree($i);
                }
                $combinationId = $randomCombination[0]->id;
                $indexvalue = "column" . $i;
                $reels[$indexvalue] = str_replace(" ", "", $randomCombination[0]->combinations);
                DB::update('UPDATE comination_free SET is_used="1" WHERE id= ?', [$combinationId]);
            }
            return _json(200, 'combinations', $reels);
        } catch (\Exception $e) {
            $data['exception_generated'] = $e->getMessage();
            $data['info'] = "Database Is Empty , Let Me Do The Reset";
            $data['waiting_time_in_seconds'] = 100;
            return response()->json($data, 200)->header('Content-Type', 'application/json');
        }
    }

    private function resetDatabase($i) {
//        $required_view = 'combinations_reel_' . $i;
        DB::update("UPDATE combinations SET used_before='0' where reel_number='" . $i . "'");
    }

    private function resetDatabasefree($i) {
//        $required_view = 'combinations_reel_' . $i;
        DB::update("UPDATE comination_free SET is_used='0' where reel_number='" . $i . "'");
    }

    public function generate1() {
        $randomCombinations = getRandomCombinations();

        return _json(200, 'combinations', $randomCombinations);
    }

    public function logout(Request $request) {
        try {

            User::where("id", Auth::user()->id)->update([
                "name" => Auth::user()->name,
                "username" => Auth::user()->username,
                "email" => Auth::user()->email,
                "password" => Auth::user()->password,
                "remember_token" => "",
                "isLogin" => "0",
            ]);

//            $request->user()->token()->revoke();
            return _json(200, 'Successfully Logged Out');
        } catch (Exception $e) {

            return _json(401, 'Error', $e);
        }
    }

    public function forgetPassword(Request $request) {
        $input = $request->all();
        $user = Auth::user();
    }

}
