<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Plan;
use App\Transaction;
use App\User;
use Illuminate\Http\Request;
use function MongoDB\BSON\fromJSON;
use Log;

class OrderController extends Controller
{
    //

    function store(Request $request){

        $input =    $request->all();
	Log::emergency('The payment system is working');

	Log::emergency(json_encode($request->all()));
//        dd($input);

        $event = $input['event'];
//        dd(json_encode($event));
        $data = $event['data'];
//        dd($data);
        $chargeId = $data['code'];

        $type = $event['type'];

//        dd($type);

//                dd($data);

        $metadata = $data['metadata'];
//        dd($metadata);
        $payments = $data['payments'];
//        dd($payments);
        $network = $payments[0]['network'];
//        dd($network);
        $txid = $payments[0]['transaction_id'];
//        dd($txid);
        $amountInUsd = $payments[0]['value']['local']['amount'];
//        dd($amountInUsd);
        $customerId = $metadata['customer_id'];
//        dd($customerId);
        $planId = $metadata['plan_id'];
//        dd($planId);


        $tranaction = Transaction::where('chargeId','=',$chargeId)->take(1)->get();
//        dd($tranaction);
        $tranaction = $tranaction[0];
	//         dd($tranaction);
	Log::emergency('The data is cleear & clean');


        if($tranaction->paymentStatus === "charge:confirmed"){
            return _json(401,"This Transaction Is Already Used & Redeemed");
        }else{
        // dd($tranaction->paymentStatus);
        $tranaction->paymentStatus = $type;
        $tranaction->amountInUsd = $amountInUsd;
        $tranaction->paymentMethod = $network;
        $tranaction->transactionId = $txid;
        $tranaction->save();

        $plansCoins = Plan::all()->where('id','=',$planId)->take(1)->pluck('planCoins');
//         dd($plansCoins[0]);
        $planCoins = $plansCoins[0];

        $user = User::find($customerId) ;

        $user->credit($planCoins);
        $user->save();
        }
        return _json(200,"Transaction Successful");
    }
}
