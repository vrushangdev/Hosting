<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Bet;

class BetController extends Controller {

    //
    public function store(Request $request) {
        $user = $request->user();
        if ($request->get('betAmount') <= $user->coin_balance) {

            $bet = new Bet();
            $bet->user_id = $user->id;
            $betAmount = request('betAmount');
            $betResult = request('betStatus');
            $betSelectedPaylines = request('payLines');
            $betTime = now();
            $betWinAmount = request('betWinAmount');
            $bet->betWinStatus = false;
//pre($betResult);    
            if ($betResult == 1) {
//                 dd($betSelectedPaylines);
                $bet->betAmount = $betAmount;
                $bet->betWinAmount = $betWinAmount;
                $user->credit($betWinAmount,$betAmount);
                $bet->betWinStatus = true;
                $user->save();
                $bet->betSelectedPayLines = ($betSelectedPaylines != null ? "" : $betSelectedPaylines);
                $bet->betTime = $betTime;
                $bet->save();
            } else {
                $user->debit($betAmount);
                $user->save();
//                 dd($user->coin_balance,$betWinAmount,$betAmount);
                // $user->debit($betAmount);
                // dd($user->coin_balance);
                // $user->save();
                $result = ['result' => $user->coin_balance, 'user_id' => $user->id];
                return _json(401, 'Bet Lost', $result);
            }


            $res = ['coin_balance' => $user->coin_balance, 'user_id' => $user->id];
            return _json(200, "Bet Won", $res);
        } else {
            $user_data = ['coin_balance' => $user->coin_balance, 'user_id' => $user->id];
            return _json(401, "not sufficient funds to play this bet", $user_data);
        }
    }

    public function getBets(Request $request) {
        $user = $request->user();

        $bet = Bet::where('user_id', $user->id)->get()->take(3);

        return _json(200, "List Of Bets", $bet);
    }

}
