<?php

namespace App\Http\Controllers;

use App\Plan;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;
use DB;
use Shakurov\Coinbase\Coinbase;

class PlanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)

    {
        //

        $plans = DB::table('plans')->get();

        return view('plans.index' , ['plans' => $plans]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('plans.create');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function view($id)
    {
        $plans = DB::select('select * from plans where id = ?',[$id]);
        return view('plans.planview',['plans'=>$plans]);
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $userEmail = auth()->user()->email;
        $plan = new Plan();
        $plan->planName = request('planName');

        $plan->planCost = request('planCost');

        $plan->planDescription = request('planDescription');
        $plan->planFeature = request('planFeature');
        $plan->planCoins = request('planCoins');
        // $plan->chargeId="FREE".$plan->id;
        $plan -> save();

        return redirect('/plancreate');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Plan  $plan
     * @return \Illuminate\Http\Response
     */
    public function show(Plan $plan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Plan  $plan
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
            $plans = DB::select('select * from plans where id = ?',[$id]);
            return view('plans.edit',['plans'=>$plans]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Plan  $plan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $name = $request->input('planName');
      $cost = $request->input('planCost');
      $description = $request->input('planDescription');
      $feature = $request->input('planFeature');
      $coins = $request->input('planCoins');
      DB::update('update plans set planName = ? , planCost = ? ,  planDescription = ?  , planFeature = ? ,  planCoins = ? where id = ?',[$name , $cost , $description , $feature , $coins , $id]);
      return redirect()->route('plan')->withStatus(__('Plan successfully updated.'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Plan  $plan
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {   

        DB::delete('delete from plans where id = ?',[$id]);
        return redirect()->route('plan')->withStatus(__('Plan successfully deleted.'));

    }
}
