<?php

namespace App\Http\Controllers;

use App\Bet;
use Illuminate\Http\Request;
use DB;

class BetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $bets = DB::table('bets')->get();

        return view('bets.index' , ['bets' => $bets] );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = $request->user();
      if(request('betAmount') >= $user->coin_balance){
            $bet = new Bet();
            $bet->user_id = $user->id;
            $betAmount = request('betAmount');
            $user->debit($betAmount);
            $betResult = request('betStatus');
            $betSelectedPaylines = request('payLines');
            $betTime = now();
            $betWinAmount=request('betWinAmount');
            $bet->betWinStatus=false;

            if($betResult){
                // dd("Do We Come Hre ? ");
                $bet->betAmount = $betAmount;
                $bet->betWinAmount = $betWinAmount;
                $user->credit($betWinAmount);
                $bet->betWinStatus=true;
                $user->save();


            }else{
                // dd($user->coin_balance,$betWinAmount,$betAmount);
                // $user->debit($betAmount);
                // dd($user->coin_balance);
                $user->save();
            return response()->json(['result'=>$user->coin_balance,'user_id'=> $user->id],200);
            }


            $bet->betSelectedPayLines = $betSelectedPaylines;
            $bet->betTime = $betTime;
            $bet->save();
            return response()->json(['result'=>$user->coin_balance,'user_id'=> $user->id],200);
        }else{
            return response()->json(['error'=>'not sufficient funds to play this bet','user_data'=>['result'=>$user->coin_balance,'user_id'=> $user->id]],200);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Bet  $bet
     * @return \Illuminate\Http\Response
     */
    public function show(Bet $bet)
    {
        //


    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Bet  $bet
     * @return \Illuminate\Http\Response
     */
    public function edit(Bet $bet)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Bet  $bet
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Bet $bet)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Bet  $bet
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::delete('delete from bets where id = ?',[$id]);
        return redirect()->route('bets')->withStatus(__('Bets successfully deleted.'));

    }
    public function getBets(Request $request){
          $user = $request->user();

    $bet=  Bet::where('user_id',$user->id)->get()->take(3);

     return _json(200,"List Of Bets",$bet);
    }
}
