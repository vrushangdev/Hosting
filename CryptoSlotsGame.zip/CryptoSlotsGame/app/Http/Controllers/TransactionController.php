<?php

namespace App\Http\Controllers;

use App\Plan;
use DB;
use Log;
use App\Transaction;
use Illuminate\Http\Request;
use Shakurov\Coinbase\Coinbase;
use App\User;

class TransactionController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $transactions = Transaction::all()->where('paymentStatus', '=', 'charge:confirmed');
        return view('transactions.index', ['transactions' => $transactions]);
    }

    public function palnshow(Request $request) {
        $dynamicplans = DB::table('plans')->get();
        $userdata = User::where("id", $request->id)->get()->toArray();
        return view('plans.show', ['dynamicplans' => $dynamicplans,"userdata"=>$userdata]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request) {
        return view('transactions.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {
        //we would simple first parse the request
        $transaction = new Transaction();
        $transaction->transactionId = request('transactionId');
        $transaction->chargeId = request('chargeId');
        $transaction->paymentMethod = request('paymentMethod');
        $transaction->paymentStatus = request('paymentStatus');
        $transaction->amountInUsd = request('amountInUsd');
        $transaction->users_id = request('users_id');
        $transaction->plan_id = request('plan_id');
        $transaction->save();
        return redirect('/transactions');
    }

    /**
     * Display the specified resource.
     *
     * @param \App\Transaction $transaction
     * @return \Illuminate\Http\Response
     */
    public function show(Transaction $transaction) {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Transaction $transaction
     * @return \Illuminate\Http\Response
     */
    public function edit(Transaction $transaction) {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Transaction $transaction
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Transaction $transaction) {
        //
    }

    public function charge(Request $request) {
        $input = $request->all();
        $user = auth()->user();
        $id = $input['coinBasePlanId'];
        $plan = Plan::where('id', $id)->first();
//        dd($plan);
        $transaction = new Transaction();
        $transaction->user_id = $user->id;
        $transaction->plan_id = $id;
        if ($plan->planCost == 0) {
            $user = auth()->user();
            $planId = $transaction->plan_id;
            // dd($planId);
            $plan = Plan::where('id', '=', $planId)->take(1)->get();
            // $plan = $plan[0];
            $plan = $plan[0];
            $coins = $plan->planCoins;
            //lets check if user already redemed it before
            $prevTransactions = Transaction::all()->where('user_id', '=', $user->id)->where('plan_id', '=', $plan->id)->count();
            // dd($prevTransactions);
            if ($prevTransactions < 10) {
                $user->credit($coins);
                $user->save();
                $transaction->paymentStatus = "charge:confirmed";
                $transaction->chargeId = "FREE";
                $transaction->transactionId = "FREE";
                $transaction->paymentMethod = "FREE";
                $transaction->amountInUsd = 0;
                $url = redirect('profile');
            } else {
                $transaction->paymentStatus = "CHARGE:PENDING";
                $transaction->chargeId = "FREEABUSE";
                $transaction->transactionId = "FREEABUSE";
                $transaction->paymentMethod = "FREEABUSE";
                $transaction->amountInUsd = 0;
                $url = redirect('profile');
            }
        } else {
            $checkout = (new \Shakurov\Coinbase\Coinbase)->createCharge([
                'name' => $plan->planName,
                'description' => $plan->planDescription,
                "metadata" => [
                    "customer_id" => $user->id,
                    "customer_name" => $user->name,
                    "plan_id" => $plan->planId,
                    "plan_amount" => $plan->amountInUsd
                ],
                'local_price' => [
                    'amount' => $plan->planCost,
                    'currency' => 'USD',
                ],
                'pricing_type' => 'fixed_price',
            ]);
            $url = redirect($checkout['data']['hosted_url']);
//        dd($checkout);
            Log::emergency('coinbase plan sent');

            if($checkout['data']['code']== null){
                $data['gateway_url']="https://commerce.coinbase.com/";
                $data['get_keys_here']="https://commerce.coinbase.com/dashboard/settings";
                return _json(200,'Kindly Setup Payment Gateway Before Using It',$data);
            }
            $transaction->chargeId = $checkout['data']['code'];
            $transaction->paymentStatus = "CHARGE:PENDING";
            $transaction->amountInUsd = $plan->planCost;
            $transaction->transactionId = "Pending";
            $transaction->paymentMethod = "COINBASE";
        }

        $transaction->save();

        return $url;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Transaction $transaction
     * @return \Illuminate\Http\Response
     */
    public function process(Request $request) {
        
    }

    public function destroy($id) {
        DB::delete('delete from transactions where id = ?', [$id]);
        return redirect()->route('transactions')->withStatus(__('Transactions successfully deleted.'));
    }

}
