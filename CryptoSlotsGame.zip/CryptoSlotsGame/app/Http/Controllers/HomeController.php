<?php

namespace App\Http\Controllers;

use App\Transaction;
use App\User;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        //lets pull off all required records here
//        $data['revenue']= Transaction::sum('amountInUsd');
        return view('user');
    }
}
