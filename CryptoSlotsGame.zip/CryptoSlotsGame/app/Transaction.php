<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Transaction extends Model
{
    //


    public function plan(){
        return $this->hasOne(Plan::class);
    }
    public function user(){
        return $this->belongsTo(User::class);

    }

}
