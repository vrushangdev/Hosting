<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;

class User extends Authenticatable implements MustVerifyEmail {

    use HasApiTokens,
        Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'username'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function credit($amount, $betAmount) {
        $this->coin_balance = ($this->coin_balance + $amount) - $betAmount;
        return $this->coin_balance;
    }

    public function debit($amount) {
        $this->coin_balance = $this->coin_balance - $amount;
        return $this->coin_balance;
    }

    public function transactions() {
        return $this->hasMany(Transaction::class);
    }

    public function bets() {
        return $this->hasMany(Bet::class);
    }

    public function isAdmin() {
        return $this->isAdmin;
    }

}
