<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Plan extends Model
{
    //
    function create(Request $request){
        return view('plans.create');
    }
    function transactions(){
        return $this->belongsToMany(Transaction::class);
    }
}
