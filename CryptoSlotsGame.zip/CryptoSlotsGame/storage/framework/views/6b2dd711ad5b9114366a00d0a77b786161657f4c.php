<?php $__env->startSection('card'); ?>

<div class="card">
    <div class="card-header">Dashboard</div>

    <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        You are logged in!
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php /**PATH C:\xampp\htdocs\new\CryptoSlotsGame\resources\views\components\card.blade.php ENDPATH**/ ?>