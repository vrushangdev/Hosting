<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div style="width:800px; margin:0 auto;" >


<div class="card-body">

                <div class="row row-example">
                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12 align-items-center">
                            <div class="card">
                                <!-- Card body -->
                                <div class="card-body">
                                        <h1 class="heading-title badge-pill bg-gradient-dark text-white">How Will It Look To Our User ? </h1>
                                    <hr/>

                                    <a href="#!">
                                        <img
                                            src="https://previews.123rf.com/images/alhovik/alhovik1802/alhovik180200045/95546187-bitcoin-jackpot-cryptocurrency-symbols-on-slot-machine-gambling-games-casino-banner-with-bright-blue.jpg"
                                            class="rounded-circle img-center img-fluid  shadow shadow-lg--hover spin"
                                            style="width: 140px;">
                                    </a>
                                    <div class="pt-4 text-center">
                                        <h5 class="h3 title">
                                            <span class="d-block mb-1"> <?php echo $plan->planName ?></span>
                                            <hr>
                                            <ul class="list-unstyled  my-4  align-content-center">
                                                <li>

                                                        <span
                                                            class="list-group-item-warning bg-gradient-indigo px-4 d-block opacity-7 py-2 my-2 rounded text-white"><strong class=""><?php echo $plan->planName ?></strong></span>
                                                </li>
                                                <li>


                                                        <span
                                                            class="list-group-item-info bg-gradient-blue opacity-7 px-4 d-block py-2 my-2 rounded text-white"><strong class=""><?php echo $plan->planDescription ?></strong></span>
                                                </li>


                                            </ul>
                                            <hr>
                                            <div
                                                class="badge-success badge-pill my-2 mx-4  px-1 py-1 text-white bg-gradient-darker">
                                                <strong>🎰 <i
                                                        class="fa fa-dollar-sign text-success"></i> <?php echo $plan->planCost ?>
                                                    💵
                                                </strong></div>
                                        </h5>
                                        <div class="mt-3">
                                            <div>


                                            </div>
                                        </div>


                                    </div>

                                </div>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm">
                        
                    </div>
                    <div class="col-sm">
                        
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new\CryptoSlotsGame\resources\views/plans/planview.blade.php ENDPATH**/ ?>