<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid mt--7">


        <div class="row">


            <div class="col-xl-8 mb-5 mb-xl-0">
                <div class="card">
            <!-- Card header -->
            <div class="card-header">
              <!-- Surtitle -->
              <h6 class="surtitle">Performance</h6>
              <!-- Title -->
              <h5 class="h3 mb-0">Total orders</h5>
            </div>
            <!-- Card body -->
            <div class="card-body">
              <div class="chart"><div class="chartjs-size-monitor"><div class="chartjs-size-monitor-expand"><div class=""></div></div><div class="chartjs-size-monitor-shrink"><div class=""></div></div></div>
                <!-- Chart wrapper -->
                <canvas id="chart-bars" class="chart-canvas chartjs-render-monitor" width="1004" height="700" style="display: block; height: 350px; width: 502px;"></canvas>
              </div>
            </div>
          </div>
            </div>

<div class="col-xl-4">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Best Selling Plans</h3>
                            </div>
                            <div class="col text-right">
                                <a href="<?php echo e(route('plan')); ?>" class="btn btn-sm btn-primary">See all</a>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <!-- Projects table -->
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">Plan Name</th>
                                    <th scope="col">Sales</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                             <?php $__currentLoopData = getBestPlans(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row">
                                       <?php echo e($plan->planName); ?>

                                    </th>
                                    <td>
                                       <?php echo e($plan->sold); ?>

                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <span class="mr-2"><?php echo e(((getPlansSold($plan->id) / 1+getTransactionTotal()) * 100)); ?>%</span>
                                            <div>
                                                <div class="progress">
                                                <div class="progress-bar bg-gradient-danger" role="progressbar" aria-valuenow="<?php echo e(((getPlansSold($plan->id)/1+getTransactionTotal()) * 100)); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e(((getPlansSold($plan->id)/1+getTransactionTotal()) * 100)); ?>%;"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-5">




        </div>

        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.extension.js"></script>
    <script charset="utf-8">

	function initChart() {

		// Create chart
        // var ordersChart = ordersChart;

		// Save to jQuery object

             $.ajax({

            url: '/api/chartData',

            type: 'GET',
            success: function (data) {

                if (!data.error) {
                     var chart = $('#chart-bars');
                    console.log(data);
                    debugger;
                    console.log(JSON.parse(data));
                    var ordersChart = new Chart(chart, JSON.parse(data));
                    console.log(ordersChart);

                    // chart.data('chart', ordersChart);


                }


            }
        });
	}
	$(document).ready(
	  initChart()
    )




    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new\CryptoSlotsGame\resources\views/admin.blade.php ENDPATH**/ ?>