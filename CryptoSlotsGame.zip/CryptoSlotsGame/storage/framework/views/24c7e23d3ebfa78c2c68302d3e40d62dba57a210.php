<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\new\CryptoSlotsGame\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>