<div class="header pb-8 pt-5 pt-lg-8 d-flex align-items-center" style="background-size: cover; background-position: center top;">
    <!-- Mask -->
    <span class="mask bg-gradient-default opacity-8"></span>
    <!-- Header container -->
    <div class="container-fluid d-flex align-items-center">
        <div class="row">
            <div class="col-lg-7 col-md-10">
                <h1 class="display-2 text-white"><?php echo e($title); ?></h1>
                <?php if(isset($description) && $description): ?>
                <p class="text-white mt-0 mb-5"><?php echo e($description); ?></p>
                <?php if(isset($id)&&$id): ?>
                <h3 class="text-wrap bg-gradient-green px-4 py-2 my-4 mr-8 rounded text-white">My Coin Balance : <?php echo e(getUserBalance($id)); ?></h3>
                <?php else: ?>
                <h3 class="text-wrap bg-gradient-green px-4 py-2 my-4 mr-8 rounded text-white">My Coin Balance : <?php echo e(getUserBalance()); ?></h3>
                <?php endif; ?>
                <?php endif; ?>
                
                <!-- Button trigger modal -->

                <?php if(\Request::is('profile')): ?>  
                <button type="button" class="btn btn-info" id="showhistory" data-toggle="modal" data-target="#showMyData">
                    Show My Previous Purchases
                </button>
                <?php endif; ?>

            </div>

        </div>
    </div>
</div> 
<?php /**PATH C:\xampp\htdocs\new\CryptoSlotsGame\resources\views\users\partials\header.blade.php ENDPATH**/ ?>